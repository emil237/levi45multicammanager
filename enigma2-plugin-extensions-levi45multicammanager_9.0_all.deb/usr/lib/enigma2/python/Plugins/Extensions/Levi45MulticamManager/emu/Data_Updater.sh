#!/bin/sh
#DESCRIPTION=This script created by Levi45
###############################################################################
rm -R /usr/lib/enigma2/python/Plugins/Extensions/Levi45MulticamManager/data/datas.pyc
rm -R /usr/lib/enigma2/python/Plugins/Extensions/Levi45MulticamManager/data/datas.pyo
###############################################################################
# Download and install Script
cd /tmp 
set -e
wget "http://levi45.spdns.eu/Addons/Multicam/data.tar.gz"

tar -xzf data.tar.gz -C /
set +e
rm -f data.tar.gz
cd ..

sync
echo "#########################################################"
echo "#                           Levi45                      #"
echo "#########################################################"
echo "#                     All Data Updated                 #"
echo "#########################################################"
echo "#                    SATELLITE-FORUM.COM                #"
echo "#########################################################"
exit 0


